/* Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/skbuff.h>
#include <linux/if_arp.h>
#include <linux/dma-mapping.h>
#include <linux/debugfs.h>
#include <linux/device.h>
#include <linux/errno.h>
#include <linux/rtnetlink.h>
#include <linux/time.h>
#include <net/arp.h>
#include <net/ip.h>
#include <net/ipv6.h>
#include <net/tcp.h>
#include <linux/usb/cdc.h>
#include "../core/mhi.h"

#ifdef CONFIG_ARCH_IPQ807x
#define CONFIG_QCA_NSS_DRV
#endif

#ifdef CONFIG_QCA_NSS_DRV
/* ***************** Callback Hooks ***************************************** */
static struct rmnet_nss_cb *rmnet_nss_callbacks __rcu __read_mostly;
/*
	depend on: qsdk/qca/feeds/nss-host/qca-nss-drv
	EXTRA_CFLAGS="-I$(STAGING_DIR)/usr/include/qca-nss-drv  $(EXTRA_CFLAGS)"
	qsdk/qca/src/data-kernel/drivers/rmnet-nss/rmnet_nss.c 
*/
#include "rmnet_nss.c"

static uint qca_nss_enabled = 1;
module_param( qca_nss_enabled, uint, S_IRUGO);
#endif

#ifndef CONFIG_MHI_NETDEV_MBIM
#define CONFIG_MHI_NETDEV_RMNET_ETH
#define QUECTEL_UL_DATA_AGG
//#define SDX55_LOOPBACK_BUG_FIX
#else
#define QUECTEL_UL_DATA_AGG
#endif

#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
static const unsigned char node_id[ETH_ALEN] = {0x02, 0x50, 0xf4, 0x00, 0x00, 0x00};
static const unsigned char default_modem_addr[ETH_ALEN] = {0x02, 0x50, 0xf3, 0x00, 0x00, 0x00};
#endif

#if defined(CONFIG_BRIDGE) || defined(CONFIG_BRIDGE_MODULE)
//#define QUECTEL_BRIDGE_MODE
#endif

#ifdef QUECTEL_BRIDGE_MODE
static uint __read_mostly bridge_mode = BIT(0)/*|BIT(1)*/;
module_param( bridge_mode, uint, S_IRUGO );
#endif

struct qmap_hdr {
    u8 cd_rsvd_pad;
    u8 mux_id;
    u16 pkt_len;
} __packed;
#define QUECTEL_QMAP_MUX_ID 0x81

#if 0
static void qmap_hex_dump(const char *tag, unsigned char *data, unsigned len) {
	uint i;
	uint *d = (uint *)data;

	printk(KERN_DEBUG "%s data=%p, len=%x\n", tag, data, len);
	len = (len+3)/4;
	for (i = 0; i < len; i+=4) {
		printk(KERN_DEBUG "%08x %08x %08x %08x %08x\n", i*4, d[i+0], d[i+1], d[i+2], d[i+3]);
	}
}
#else
static void qmap_hex_dump(const char *tag, unsigned char *data, unsigned len) {
}
#endif

#ifndef CONFIG_MHI_NETDEV_MBIM
static uint __read_mostly qmap_mode = 1;
module_param(qmap_mode, uint, S_IRUGO);
#endif

static uint poll_weight = NAPI_POLL_WEIGHT;
module_param(poll_weight, uint, S_IRUGO);

#define MHI_NETDEV_DRIVER_NAME "mhi_netdev"
#define WATCHDOG_TIMEOUT (30 * HZ)

#define MSG_VERB(fmt, ...) do { \
	if (mhi_netdev->msg_lvl <= MHI_MSG_LVL_VERBOSE) \
		pr_err("[D][%s] " fmt, __func__, ##__VA_ARGS__);\
} while (0)

#define MHI_ASSERT(cond, msg) do { \
	if (cond) { \
		MSG_ERR(msg); \
		WARN_ON(cond); \
	} \
} while (0)

#define MSG_LOG(fmt, ...) do { \
	if (mhi_netdev->msg_lvl <= MHI_MSG_LVL_INFO) \
		pr_err("[I][%s] " fmt, __func__, ##__VA_ARGS__);\
} while (0)

#define MSG_ERR(fmt, ...) do { \
	if (mhi_netdev->msg_lvl <= MHI_MSG_LVL_ERROR) \
		pr_err("[E][%s] " fmt, __func__, ##__VA_ARGS__); \
} while (0)

struct mhi_stats {
	u32 rx_int;
	u32 tx_full;
	u32 tx_pkts;
	u32 rx_budget_overflow;
	u32 tx_allocated;
	u32 rx_allocated;
	u32 alloc_failed;
};

/* important: do not exceed sk_buf->cb (48 bytes) */
struct mhi_skb_priv {
	void *buf;
	size_t size;
	struct mhi_netdev *mhi_netdev;
};

struct skb_data {	/* skb->cb is one of these */
	struct mhi_netdev *bind_netdev;
	unsigned int length;
	unsigned int packets;
	unsigned int can_recycle;
};

#if (LINUX_VERSION_CODE > KERNEL_VERSION( 4,11,0 ))
#define MHI_NETDEV_STATUS64 1
#endif

#if defined(QUECTEL_UL_DATA_AGG)
static uint agg_time_limit __read_mostly = 10; //ms
module_param(agg_time_limit, uint, S_IRUGO | S_IWUSR);

struct tx_agg_ctx {
	struct hrtimer tx_timer;
	struct tasklet_struct tx_bh;
	uint tx_pending_count;
	uint tx_pending_size;
	uint tx_sending_pkts;
	uint tx_timer_active;
	uint tx_timer_pkts;
	/* QMIWDS_ADMIN_SET_DATA_FORMAT_RESP TLV_0x17 and TLV_0x18 */
	uint ul_data_aggregation_max_datagrams; //UplinkDataAggregationMaxDatagramsTlv
	uint ul_data_aggregation_max_size; //UplinkDataAggregationMaxSizeTlv
	struct sk_buff *tx_pending_skb[16];

	uint tx_agg_match[8];
	uint qmap_rx_pkts[8];
	uint qmap_tx_pkts[8];
};
#endif

//#define TS_DEBUG
struct mhi_netdev {
	int alias;
	struct mhi_device *mhi_dev;
	spinlock_t rx_lock;
	bool enabled;
	rwlock_t pm_lock; /* state change lock */
	int (*rx_queue)(struct mhi_netdev *mhi_netdev, gfp_t gfp_t);
	struct work_struct alloc_work;
	int wake;

	struct sk_buff_head tx_allocated;
	struct sk_buff_head rx_allocated;
	struct sk_buff_head qmap_chain;
	struct sk_buff_head skb_chain;
#ifdef TS_DEBUG
	uint clear_ts;
	struct timespec diff_ts;
	struct timespec qmap_ts;
	struct timespec skb_ts;
#endif

	u32 mru;
	const char *interface_name;
	struct napi_struct napi;
	struct net_device *ndev;
	struct sk_buff *frag_skb;
	bool recycle_buf;

#if defined(MHI_NETDEV_STATUS64)
	struct pcpu_sw_netstats __percpu *stats64;
#endif
	struct mhi_stats stats;

	struct dentry *dentry;
	enum MHI_DEBUG_LEVEL msg_lvl;
#ifdef CONFIG_MHI_NETDEV_MBIM
	u16 tx_seq;
	u16 rx_seq;
	u32 rx_max;
#endif
	struct net_device *mpQmapNetDev[8];
	u32 qmap_mode;
	u32 qmap_size;
	u32 link_state;

#if defined(QUECTEL_UL_DATA_AGG)
	struct tx_agg_ctx tx_ctx;
#endif

#ifdef QUECTEL_BRIDGE_MODE
	uint bridge_mode;
	uint bridge_ipv4;
	unsigned char bridge_mac[ETH_ALEN];
#endif
};

struct mhi_netdev_priv {
	struct mhi_netdev *mhi_netdev;
};

struct qmap_priv {
	struct net_device *real_dev;
	u8 offset_id;
#ifdef QUECTEL_BRIDGE_MODE
	uint bridge_mode;
	uint bridge_ipv4;
	unsigned char bridge_mac[ETH_ALEN];
#endif
};

static struct mhi_netdev *ndev_to_mhi(struct net_device *ndev) {
	struct mhi_netdev_priv *mhi_netdev_priv = netdev_priv(ndev);
	struct mhi_netdev *mhi_netdev = mhi_netdev_priv->mhi_netdev;
	return mhi_netdev;
}

static struct mhi_driver mhi_netdev_driver;
static void mhi_netdev_create_debugfs(struct mhi_netdev *mhi_netdev);

#ifdef CONFIG_MHI_NETDEV_MBIM
static int mhi_mbim_rx_fixup(struct mhi_netdev *mhi_netdev, struct sk_buff *skb_in, struct net_device *dev);
#else
static int mhi_qmap_rx_fixup(struct mhi_netdev *mhi_netdev, struct sk_buff *skb_in, struct net_device *qmap_net);
#endif

#if 0
static void mhi_netdev_skb_destructor(struct sk_buff *skb)
{
	struct mhi_skb_priv *skb_priv = (struct mhi_skb_priv *)(skb->cb);
	struct mhi_netdev *mhi_netdev = skb_priv->mhi_netdev;

	skb->data = skb->head;
	skb_reset_tail_pointer(skb);
	skb->len = 0;
	MHI_ASSERT(skb->data != skb_priv->buf, "incorrect buf");
	skb_queue_tail(&mhi_netdev->rx_allocated, skb);
}
#endif
	
#ifdef QUECTEL_BRIDGE_MODE
static const struct net_device_ops mhi_netdev_ops_ip;
static const struct net_device_ops qmap_netdev_ops;

static int is_qmap_netdev(const struct net_device *ndev) {
	return ndev->netdev_ops == &qmap_netdev_ops;
}

static int bridge_arp_reply(struct net_device *net, struct sk_buff *skb, uint bridge_ipv4) {
	struct arphdr *parp;
	u8 *arpptr, *sha;
	u8  sip[4], tip[4], ipv4[4];
	struct sk_buff *reply = NULL;

	ipv4[0]  = (bridge_ipv4 >> 24) & 0xFF;
	ipv4[1]  = (bridge_ipv4 >> 16) & 0xFF;
	ipv4[2]  = (bridge_ipv4 >> 8) & 0xFF;
	ipv4[3]  = (bridge_ipv4 >> 0) & 0xFF;

	parp = arp_hdr(skb);

	if (parp->ar_hrd == htons(ARPHRD_ETHER)  && parp->ar_pro == htons(ETH_P_IP)
		&& parp->ar_op == htons(ARPOP_REQUEST) && parp->ar_hln == 6 && parp->ar_pln == 4) {
		arpptr = (u8 *)parp + sizeof(struct arphdr);
		sha = arpptr;
		arpptr += net->addr_len;	/* sha */
		memcpy(sip, arpptr, sizeof(sip));
		arpptr += sizeof(sip);
		arpptr += net->addr_len;	/* tha */
		memcpy(tip, arpptr, sizeof(tip));

		pr_info("%s sip = %d.%d.%d.%d, tip=%d.%d.%d.%d, ipv4=%d.%d.%d.%d\n", netdev_name(net),
		sip[0], sip[1], sip[2], sip[3], tip[0], tip[1], tip[2], tip[3], ipv4[0], ipv4[1], ipv4[2], ipv4[3]);
		//wwan0 sip = 10.151.137.255, tip=10.151.138.0, ipv4=10.151.137.255
		if (tip[0] == ipv4[0] && tip[1] == ipv4[1] && (tip[2]&0xFC) == (ipv4[2]&0xFC) && tip[3] != ipv4[3])
			reply = arp_create(ARPOP_REPLY, ETH_P_ARP, *((__be32 *)sip), net, *((__be32 *)tip), sha, default_modem_addr, sha);

		if (reply) {
			skb_reset_mac_header(reply);
			__skb_pull(reply, skb_network_offset(reply));
			reply->ip_summed = CHECKSUM_UNNECESSARY;
			reply->pkt_type = PACKET_HOST;

			netif_rx_ni(reply);
		}
		return 1;
	}

    return 0;
}

static struct sk_buff *bridge_mode_tx_fixup(struct net_device *net, struct sk_buff *skb, uint bridge_ipv4, unsigned char *bridge_mac) {
	struct ethhdr *ehdr;
	const struct iphdr *iph;

	skb_reset_mac_header(skb);
	ehdr = eth_hdr(skb);

	if (ehdr->h_proto == htons(ETH_P_ARP)) {
		if (bridge_ipv4)
			bridge_arp_reply(net, skb, bridge_ipv4);
		return NULL;
	}

	iph = ip_hdr(skb);
	//DBG("iphdr: ");
	//PrintHex((void *)iph, sizeof(struct iphdr));

// 1	0.000000000	0.0.0.0	255.255.255.255	DHCP	362	DHCP Request  - Transaction ID 0xe7643ad7
	if (ehdr->h_proto == htons(ETH_P_IP) && iph->protocol == IPPROTO_UDP && iph->saddr == 0x00000000 && iph->daddr == 0xFFFFFFFF) {
		//if (udp_hdr(skb)->dest == htons(67)) //DHCP Request
		{
			memcpy(bridge_mac, ehdr->h_source, ETH_ALEN);
			pr_info("%s PC Mac Address: %02x:%02x:%02x:%02x:%02x:%02x\n", netdev_name(net),
				bridge_mac[0], bridge_mac[1], bridge_mac[2], bridge_mac[3], bridge_mac[4], bridge_mac[5]);
		}
	}

	if (memcmp(ehdr->h_source, bridge_mac, ETH_ALEN)) {
		return NULL;
	}

	return skb;
}

static void bridge_mode_rx_fixup(struct mhi_netdev *mhi_netdev, struct net_device *net, struct sk_buff *skb) {
	uint bridge_mode = 0;
	unsigned char *bridge_mac;

	if (mhi_netdev->qmap_mode > 1) {
		struct qmap_priv *priv = netdev_priv(net);
		bridge_mode = priv->bridge_mode;
		bridge_mac = priv->bridge_mac;
	}
	else {
		bridge_mode = mhi_netdev->bridge_mode;
		bridge_mac = mhi_netdev->bridge_mac;
	}

	if (bridge_mode)
		memcpy(eth_hdr(skb)->h_dest, bridge_mac, ETH_ALEN);
}

static ssize_t bridge_mode_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	uint bridge_mode = 0;

	if (is_qmap_netdev(ndev)) {
		struct qmap_priv *priv = netdev_priv(ndev);
		bridge_mode = priv->bridge_mode;
	}
	else {
		struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
		bridge_mode = mhi_netdev->bridge_mode;
	}

	return snprintf(buf, PAGE_SIZE, "%u\n", bridge_mode);
}

static ssize_t bridge_ipv4_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	unsigned int bridge_ipv4 = 0;
	unsigned char ipv4[4];

	if (is_qmap_netdev(ndev)) {
		struct qmap_priv *priv = netdev_priv(ndev);
		bridge_ipv4 = priv->bridge_ipv4;
	}
	else {
		struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
		bridge_ipv4 = mhi_netdev->bridge_ipv4;
	}

	ipv4[0]  = (bridge_ipv4 >> 24) & 0xFF;
	ipv4[1]  = (bridge_ipv4 >> 16) & 0xFF;
	ipv4[2]  = (bridge_ipv4 >> 8) & 0xFF;
	ipv4[3]  = (bridge_ipv4 >> 0) & 0xFF;

	return snprintf(buf, PAGE_SIZE, "%d.%d.%d.%d\n",  ipv4[0], ipv4[1], ipv4[2], ipv4[3]);
}

static ssize_t bridge_ipv4_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count) {
	struct net_device *ndev = to_net_dev(dev);

	if (is_qmap_netdev(ndev)) {
		struct qmap_priv *priv = netdev_priv(ndev);
		priv->bridge_ipv4 = simple_strtoul(buf, NULL, 16);
	}
	else {
		struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
		mhi_netdev->bridge_ipv4 = simple_strtoul(buf, NULL, 16);
	}

	return count;
}

static DEVICE_ATTR(bridge_mode,  S_IRUGO, bridge_mode_show, NULL);
static DEVICE_ATTR(bridge_ipv4, S_IWUSR | S_IRUGO, bridge_ipv4_show, bridge_ipv4_store);
#endif

static __u32 skb_qlen(struct sk_buff_head *list)
{
	unsigned long flags;
	__u32 qlen = 0;;

	spin_lock_irqsave(&list->lock, flags);
	qlen = list->qlen;
	spin_unlock_irqrestore(&list->lock, flags);
	return qlen;
}

static void mhi_netdev_recycle_skb(struct sk_buff_head *list, struct sk_buff *skb) {
	skb->data = skb->head;
	skb_reset_tail_pointer(skb);
	skb->len = 0;
	skb_queue_tail(list, skb);
}

static int mhi_netdev_alloc_skb(struct mhi_netdev *mhi_netdev, gfp_t gfp_t)
{
	u32 cur_mru = mhi_netdev->mru;
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	struct mhi_skb_priv *skb_priv;
	int ret;
	struct sk_buff *skb;
	int no_tre = mhi_get_no_free_descriptors(mhi_dev, DMA_FROM_DEVICE);
	int i;

	for (i = skb_qlen(&mhi_netdev->rx_allocated); i < no_tre; i++) {
		skb = alloc_skb(32+cur_mru, gfp_t);
		if (skb)
			skb_queue_tail(&mhi_netdev->rx_allocated, skb);
	}

	for (i = 0; i < no_tre; i++) {
		skb = skb_dequeue(&mhi_netdev->rx_allocated);
		if (!skb)
			return -ENOMEM;

		read_lock_bh(&mhi_netdev->pm_lock);
		if (unlikely(!mhi_netdev->enabled)) {
			MSG_ERR("Interface not enabled\n");
			ret = -EIO;
			goto error_queue;
		}

		skb_priv = (struct mhi_skb_priv *)skb->cb;
		skb_priv->buf = skb->data;
		skb_priv->size = cur_mru;
		skb_priv->mhi_netdev = mhi_netdev;
		skb->dev = mhi_netdev->ndev;
		skb_reserve(skb, 32); //for ethernet header

		spin_lock_bh(&mhi_netdev->rx_lock);
		ret = mhi_queue_transfer(mhi_dev, DMA_FROM_DEVICE, skb,
					 skb_priv->size, MHI_EOT);
		spin_unlock_bh(&mhi_netdev->rx_lock);

		if (ret) {
			skb_priv->mhi_netdev = NULL;
			MSG_ERR("Failed to queue skb, ret:%d\n", ret);
			ret = -EIO;
			goto error_queue;
		}

		read_unlock_bh(&mhi_netdev->pm_lock);
	}

	return 0;

error_queue:
	skb->destructor = NULL;
	read_unlock_bh(&mhi_netdev->pm_lock);
	dev_kfree_skb_any(skb);

	return ret;
}

static void mhi_netdev_alloc_work(struct work_struct *work)
{
	struct mhi_netdev *mhi_netdev = container_of(work, struct mhi_netdev,
						   alloc_work);
	/* sleep about 1 sec and retry, that should be enough time
	 * for system to reclaim freed memory back.
	 */
	const int sleep_ms =  1000;
	int retry = 60;
	int ret;

	MSG_LOG("Entered\n");
	do {
		ret = mhi_netdev_alloc_skb(mhi_netdev, GFP_KERNEL);
		/* sleep and try again */
		if (ret == -ENOMEM) {
			msleep(sleep_ms);
			retry--;
		}
	} while (ret == -ENOMEM && retry);

	MSG_LOG("Exit with status:%d retry:%d\n", ret, retry);
}

static void mhi_netdev_dealloc(struct mhi_netdev *mhi_netdev)
{
	struct sk_buff *skb;

	skb = skb_dequeue(&mhi_netdev->rx_allocated);
	while (skb) {
		skb->destructor = NULL;
		kfree_skb(skb);
		skb = skb_dequeue(&mhi_netdev->rx_allocated);
	}
}

static int mhi_netdev_poll(struct napi_struct *napi, int budget)
{
	struct net_device *ndev = napi->dev;
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	struct sk_buff		*skb;
	int rx_work = 0;
	int ret;
#ifdef TS_DEBUG
	struct timespec ts1, ts2;
#endif

	MSG_VERB("Entered\n");

	read_lock_bh(&mhi_netdev->pm_lock);

	if (!mhi_netdev->enabled) {
		MSG_LOG("interface is disabled!\n");
		napi_complete(napi);
		read_unlock_bh(&mhi_netdev->pm_lock);
		return 0;
	}

	mhi_device_get(mhi_dev);

#ifdef TS_DEBUG
	getnstimeofday(&ts1);
#endif
	if (skb_qlen(&mhi_netdev->qmap_chain) < (budget/2)) {
		rx_work = mhi_poll(mhi_dev, (budget/2));
		if (rx_work < 0) {
			MSG_ERR("Error polling ret:%d\n", rx_work);
			rx_work = 0;
			napi_complete(napi);
			goto exit_poll;
		}
	}

	while ((skb_qlen(&mhi_netdev->skb_chain) < budget)
		&& (skb = skb_dequeue (&mhi_netdev->qmap_chain))) {
		struct mhi_skb_priv *skb_priv = (struct mhi_skb_priv *)(skb->cb);

#ifdef CONFIG_MHI_NETDEV_MBIM
		mhi_mbim_rx_fixup(mhi_netdev, skb, ndev);
#else
		mhi_qmap_rx_fixup(mhi_netdev, skb, ndev);
#endif
		skb_priv->mhi_netdev = NULL;
		dev_kfree_skb_any(skb);
	}

#ifdef TS_DEBUG
	getnstimeofday(&ts2);
	mhi_netdev->qmap_ts = timespec_add(mhi_netdev->qmap_ts, timespec_sub(ts2, ts1));
#endif

	rx_work = 0;
	while ((skb = skb_dequeue (&mhi_netdev->skb_chain))) {
#ifdef CONFIG_QCA_NSS_DRV
		/* Pass off the packet to NSS driver if we can */
		struct rmnet_nss_cb *nss_cb = rcu_dereference(rmnet_nss_callbacks);
		if (nss_cb) {
			nss_cb->nss_tx(skb);
			//pr_err("nss_tx(%s)=%d\n", netdev_name(dev->net), rc);
		}
		else
#endif
		netif_receive_skb(skb);
		rx_work++;
	}
	if (rx_work > budget)
		rx_work = budget;

#ifdef TS_DEBUG
	getnstimeofday(&ts1);
	mhi_netdev->skb_ts = timespec_add(mhi_netdev->skb_ts, timespec_sub(ts1, ts2));
	if (mhi_netdev->clear_ts) {
		struct timespec zero_ts = {0, 0};
		mhi_netdev->qmap_ts = zero_ts;
		mhi_netdev->skb_ts = zero_ts;
		mhi_netdev->clear_ts = 0;
	}
#endif

	/* queue new buffers */
	ret = mhi_netdev->rx_queue(mhi_netdev, GFP_ATOMIC);
	if (ret == -ENOMEM) {
		MSG_LOG("out of tre, queuing bg worker\n");
		mhi_netdev->stats.alloc_failed++;
		schedule_work(&mhi_netdev->alloc_work);
	}

	/* complete work if # of packet processed less than allocated budget */
	if (rx_work < budget)
		napi_complete(napi);
	else
		mhi_netdev->stats.rx_budget_overflow++;

exit_poll:
	mhi_device_put(mhi_dev);
	read_unlock_bh(&mhi_netdev->pm_lock);

	MSG_VERB("polled %d pkts\n", rx_work);

	return rx_work;
}

static int mhi_netdev_open(struct net_device *ndev)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;

	MSG_LOG("Opened net dev interface\n");

	/* tx queue may not necessarily be stopped already
	 * so stop the queue if tx path is not enabled
	 */
	if (!mhi_dev->ul_chan)
		netif_stop_queue(ndev);
	else
		netif_start_queue(ndev);

	return 0;

}

static int mhi_netdev_change_mtu(struct net_device *ndev, int new_mtu)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;

	if (new_mtu < 0 || mhi_dev->mtu < new_mtu)
		return -EINVAL;

	ndev->mtu = new_mtu;
	return 0;
}

static void mhi_netdev_upate_rx_stats(struct mhi_netdev *mhi_netdev,
			unsigned rx_packets, unsigned rx_bytes) {
#if defined(MHI_NETDEV_STATUS64)
	struct pcpu_sw_netstats *stats64 = this_cpu_ptr(mhi_netdev->stats64);
	unsigned long flags;

	flags = u64_stats_update_begin_irqsave(&stats64->syncp);
	stats64->rx_packets += rx_packets;
	stats64->rx_bytes += rx_bytes;
	u64_stats_update_end_irqrestore(&stats64->syncp, flags);
#else
	mhi_netdev->ndev->stats.rx_packets += rx_packets;
	mhi_netdev->ndev->stats.rx_bytes += rx_bytes;
#endif
}

static void mhi_netdev_upate_tx_stats(struct mhi_netdev *mhi_netdev,
			unsigned tx_packets, unsigned tx_bytes) {
#if defined(MHI_NETDEV_STATUS64)
	struct pcpu_sw_netstats *stats64 = this_cpu_ptr(mhi_netdev->stats64);
	unsigned long flags;

	flags = u64_stats_update_begin_irqsave(&stats64->syncp);
	stats64->tx_packets += tx_packets;
	stats64->tx_bytes += tx_bytes;
	u64_stats_update_end_irqrestore(&stats64->syncp, flags);
#else
	mhi_netdev->ndev->stats.tx_packets += tx_packets;
	mhi_netdev->ndev->stats.tx_bytes += tx_bytes;
#endif
}

#ifdef CONFIG_MHI_NETDEV_MBIM
static int expect_skb_len(struct sk_buff **skb_arr, int skb_cnt)
{
    int i;
    int expect_sz = sizeof(struct usb_cdc_ncm_nth16) +
                    sizeof(struct usb_cdc_ncm_ndp16) +
                    sizeof(struct usb_cdc_ncm_dpe16) * (skb_cnt + 1);

    for (i = 0; i < skb_cnt; i++)
        expect_sz += skb_arr[i]->len;

    return expect_sz;
}

static void mhi_mbim_tx_fill_frames(struct mhi_netdev *mhi_netdev,
                                               struct sk_buff *skb_out, struct sk_buff **skbs, uint skb_cnt)
{
    struct usb_cdc_ncm_nth16 *nth16;
    struct usb_cdc_ncm_ndp16 *ndp16;
    int expect_len;
    int offset;
    int i;
    __le32 sign;
    u8 *c;
    u16 tci = 0;

    if (skb_cnt < 1 || !skb_out || !skbs)
	    return;

    expect_len = expect_skb_len(skbs, skb_cnt);
    if (expect_len > skb_tailroom(skb_out))
    {
	    MSG_ERR("too much skbs, cannot send that much\n");
	    return;
    }

    skb_put(skb_out, expect_len);
    // ncm header
    nth16 = (struct usb_cdc_ncm_nth16 *)skb_out->data;
    nth16->dwSignature = cpu_to_le32(USB_CDC_NCM_NTH16_SIGN);
    nth16->wHeaderLength = cpu_to_le16(sizeof(struct usb_cdc_ncm_nth16));
    nth16->wSequence = cpu_to_le16(mhi_netdev->tx_seq++);
    nth16->wBlockLength = cpu_to_le16(expect_len);
    nth16->wNdpIndex = cpu_to_le16(sizeof(struct usb_cdc_ncm_nth16));

    sign = cpu_to_le32(USB_CDC_MBIM_NDP16_IPS_SIGN);
    c = (u8 *)&sign;
    tci = 0;
    c[3] = tci;

    ndp16 = (struct usb_cdc_ncm_ndp16 *)(skb_out->data + sizeof(struct usb_cdc_ncm_nth16));
    ndp16->dwSignature = sign;
    ndp16->wLength = cpu_to_le16(
		    sizeof(struct usb_cdc_ncm_ndp16) +
		    sizeof(struct usb_cdc_ncm_dpe16) * (skb_cnt + 1));
    ndp16->wNextNdpIndex = 0;

    // rawip data part
    offset = sizeof(struct usb_cdc_ncm_nth16) +
	    sizeof(struct usb_cdc_ncm_ndp16) +
	    sizeof(struct usb_cdc_ncm_dpe16) * (skb_cnt + 1);
    for (i = 0; i < skb_cnt; i++)
    {
	    ndp16->dpe16[i].wDatagramIndex = cpu_to_le16(offset);
	    ndp16->dpe16[i].wDatagramLength = cpu_to_le16(skbs[i]->len);
        memcpy(skb_out->data + ndp16->dpe16[i].wDatagramIndex, skbs[i]->data, skbs[i]->len);
	    offset += skbs[i]->len;
    }
    ndp16->dpe16[i].wDatagramIndex = 0;
    ndp16->dpe16[i].wDatagramLength = 0;

    return;
}

static int mhi_mbim_rx_fixup(struct mhi_netdev *mhi_netdev, struct sk_buff *skb_in, struct net_device *dev) {
	struct usb_cdc_ncm_nth16 *nth16;
	int ndpoffset, len;
	u16 wSequence;
	struct mhi_netdev *ctx = mhi_netdev;

	unsigned rx_packets = 0;
	unsigned rx_bytes = 0;

	if (skb_in->len < (sizeof(struct usb_cdc_ncm_nth16) + sizeof(struct usb_cdc_ncm_ndp16))) {
		MSG_ERR("frame too short\n");
		goto error;
	}

	nth16 = (struct usb_cdc_ncm_nth16 *)skb_in->data;

	if (nth16->dwSignature != cpu_to_le32(USB_CDC_NCM_NTH16_SIGN)) {
		MSG_ERR("invalid NTH16 signature <%#010x>\n", le32_to_cpu(nth16->dwSignature));
		goto error;
	}

	len = le16_to_cpu(nth16->wBlockLength);
	if (len > ctx->rx_max) {
		MSG_ERR("unsupported NTB block length %u/%u\n", len, ctx->rx_max);
		goto error;
	}

	wSequence = le16_to_cpu(nth16->wSequence);
	if (ctx->rx_seq !=  wSequence) {
		MSG_ERR("sequence number glitch prev=%d curr=%d\n", ctx->rx_seq, wSequence);
	}
	ctx->rx_seq = wSequence + 1;

	ndpoffset = nth16->wNdpIndex;

	while (ndpoffset > 0) {
		struct usb_cdc_ncm_ndp16 *ndp16 ;
		struct usb_cdc_ncm_dpe16 *dpe16;
		int nframes, x;
		u8 *c;
		u16 tci = 0;

		if (skb_in->len < (ndpoffset + sizeof(struct usb_cdc_ncm_ndp16))) {
			MSG_ERR("invalid NDP offset  <%u>\n", ndpoffset);
			goto error;
		}

		ndp16 = (struct usb_cdc_ncm_ndp16 *)(skb_in->data + ndpoffset);

		if (le16_to_cpu(ndp16->wLength) < 0x10) {
			MSG_ERR("invalid DPT16 length <%u>\n", le16_to_cpu(ndp16->wLength));
			goto error;
		}

		nframes = ((le16_to_cpu(ndp16->wLength) - sizeof(struct usb_cdc_ncm_ndp16)) / sizeof(struct usb_cdc_ncm_dpe16));

		if (skb_in->len < (sizeof(struct usb_cdc_ncm_ndp16) + nframes * (sizeof(struct usb_cdc_ncm_dpe16)))) {
			MSG_ERR("Invalid nframes = %d\n", nframes);
			goto error;
		}

		switch (ndp16->dwSignature & cpu_to_le32(0x00ffffff)) {
			case cpu_to_le32(USB_CDC_MBIM_NDP16_IPS_SIGN):
				c = (u8 *)&ndp16->dwSignature;
				tci = c[3];
				/* tag IPS<0> packets too if MBIM_IPS0_VID exists */
				//if (!tci && info->flags & FLAG_IPS0_VLAN)
				//	tci = MBIM_IPS0_VID;
			break;
			case cpu_to_le32(USB_CDC_MBIM_NDP16_DSS_SIGN):
				c = (u8 *)&ndp16->dwSignature;
				tci = c[3] + 256;
			break;
			default:
				MSG_ERR("unsupported NDP signature <0x%08x>\n", le32_to_cpu(ndp16->dwSignature));
			goto error;
		}

		if (tci != 0) {
			MSG_ERR("unsupported tci %d by now\n", tci);
			goto error;
		}

		dpe16 = ndp16->dpe16;

		for (x = 0; x < nframes; x++, dpe16++) {
			int offset = le16_to_cpu(dpe16->wDatagramIndex);
			int skb_len = le16_to_cpu(dpe16->wDatagramLength);
			struct sk_buff *skb;

			if (offset == 0 || skb_len == 0) {
				break;
			}

			/* sanity checking */
			if (((offset + skb_len) > skb_in->len) || (skb_len > ctx->rx_max)) {
				MSG_ERR("invalid frame detected (ignored) x=%d, offset=%d, skb_len=%u\n", x, offset, skb_len);
				goto error;
			}

			skb = skb_clone(skb_in, GFP_ATOMIC);
			if (!skb) {
				MSG_ERR("skb_clone fail\n");
				goto error;
			}

			skb_pull(skb, offset);
			skb_trim(skb, skb_len);
			switch (skb->data[0] & 0xf0) {
				case 0x40:
					skb->protocol = htons(ETH_P_IP);
				break;
				case 0x60:
					skb->protocol = htons(ETH_P_IPV6);
				break;
				default:
					MSG_ERR("unknow skb->protocol %02x\n", skb->data[0]);
					goto error;
			}
			skb_reset_mac_header(skb);
			netif_receive_skb(skb);
			rx_packets++;
			rx_bytes += skb->len;				
		}

		/* are there more NDPs to process? */
		ndpoffset = le16_to_cpu(ndp16->wNextNdpIndex);
	}

	mhi_netdev_upate_rx_stats(mhi_netdev, rx_packets, rx_bytes);

error:
	return rx_packets;
}
#endif
#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
static struct sk_buff * ether_to_ip_fixup(struct sk_buff *skb) {
	const struct ethhdr *ehdr;

	skb_reset_mac_header(skb);
	ehdr = eth_hdr(skb);

	if (likely(ehdr->h_proto == htons(ETH_P_IP) || ehdr->h_proto == htons(ETH_P_IPV6))) {
		if (likely(skb_pull(skb, ETH_HLEN)))
			return skb;
	}
	
	return NULL;
}

static struct sk_buff * ip_to_ether_fixup(struct sk_buff *skb) {
	struct ethhdr *ehdr;

	skb_push(skb, ETH_HLEN);
	skb_reset_mac_header(skb);
	ehdr = eth_hdr(skb);

	ehdr->h_proto =  skb->protocol;
	memcpy(ehdr->h_source, default_modem_addr, ETH_ALEN);
	memcpy(ehdr->h_dest, skb->dev->dev_addr, ETH_ALEN);
	skb->protocol = eth_type_trans(skb, skb->dev);

	return skb;
}

static struct sk_buff * add_qhdr(struct sk_buff *skb, u8 mux_id) {
	struct qmap_hdr *qhdr;
	int pad = 0;

	pad = skb->len%4;
	if (pad) {
		pad = 4 - pad;
		if (skb_tailroom(skb) < pad) {
			printk("skb_tailroom small!\n");
			pad = 0;
		}
		if (pad)
			__skb_put(skb, pad);
	}
					
	qhdr = (struct qmap_hdr *)skb_push(skb, sizeof(struct qmap_hdr));
	qhdr->cd_rsvd_pad = pad;
	qhdr->mux_id = mux_id;
	qhdr->pkt_len = cpu_to_be16(skb->len - sizeof(struct qmap_hdr));

	return skb;
}

static struct sk_buff *mhi_qmap_tx_fixup(struct mhi_netdev *mhi_netdev, struct sk_buff *skb, struct net_device *dev) {
	if (skb_headroom(skb) < sizeof(struct qmap_hdr)) {
		dev_kfree_skb_any(skb);
		printk("skb_headroom small!\n");
		return NULL;
	}
				
	return add_qhdr(skb, QUECTEL_QMAP_MUX_ID);
}

static int mhi_qmap_rx_fixup(struct mhi_netdev *mhi_netdev, struct sk_buff *skb_in, struct net_device *dev) {
	unsigned rx_packets = 0;
	unsigned rx_bytes = 0;
	int headroom = 0;
#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
	const int need_headroot = ETH_HLEN;
#else
	const int need_headroot = 0;
#endif

	headroom = skb_headroom(skb_in);

	while (skb_in->len > sizeof(struct qmap_hdr))
	{
		struct qmap_hdr *qhdr = (struct qmap_hdr *)skb_in->data;
		struct sk_buff *qmap_skb = NULL;
		struct net_device *qmap_net;
		int pkt_len = be16_to_cpu(qhdr->pkt_len);
		int skb_len;
		__be16 protocol;
		u8 offset_id = 0;
         
#ifdef SDX55_LOOPBACK_BUG_FIX
		if (pkt_len > 1500) {
			struct iphdr *iphdr = (struct iphdr *)(skb_in->data + sizeof(struct qmap_hdr)); 			
			if (iphdr->version == 4 && iphdr->protocol == 17 && be16_to_cpu(iphdr->tot_len) == 1498) {
				pkt_len = 1500;
			}
		}

		if (pkt_len <= 1500) {
			struct iphdr *iphdr = (struct iphdr *)(skb_in->data + sizeof(struct qmap_hdr)); 
			if (iphdr->version == 4 && iphdr->protocol == 17) {
				if (iphdr->saddr == 0xab30a8c0 && iphdr->daddr == 0xac30a8c0) {
					iphdr->saddr = 0xac30a8c0; //192.168.48.172
					iphdr->daddr = 0xab30a8c0; //192.168.48.171
				}
				if (iphdr->saddr != 0xac30a8c0 || iphdr->daddr != 0xab30a8c0) {
					printk(KERN_DEBUG "saddr=%x, daddr=%x\n", iphdr->saddr, iphdr->daddr);
				}
			}
		}
#endif

		skb_len = pkt_len - (qhdr->cd_rsvd_pad&0x3F);
		if (skb_len > 1500) {
			MSG_ERR("drop skb_len=%x larger than 1500\n", skb_len);
			goto error_pkt;
		}

		if (skb_in->len < (pkt_len + sizeof(struct qmap_hdr))) {
			MSG_ERR("drop qmap unknow pkt, len=%d, pkt_len=%d\n", skb_in->len, pkt_len);
			goto error_pkt;
		}

		if (qhdr->cd_rsvd_pad & 0x80) {
			MSG_ERR("skip qmap command packet %x\n", qhdr->cd_rsvd_pad);
			goto skip_pkt;
		}

		offset_id = qhdr->mux_id - QUECTEL_QMAP_MUX_ID;
		if (offset_id >= mhi_netdev->qmap_mode) {
			MSG_ERR("drop qmap unknow mux_id %x\n", qhdr->mux_id);
			goto error_pkt;
		}

		qmap_net = mhi_netdev->mpQmapNetDev[offset_id];
		if (qmap_net == NULL) {
			MSG_ERR("drop qmap unknow mux_id %x\n", qhdr->mux_id);
			goto error_pkt;
		}

		switch (skb_in->data[sizeof(struct qmap_hdr)] & 0xf0) {
			case 0x40:
				protocol = htons(ETH_P_IP);
			break;
			case 0x60:
				protocol = htons(ETH_P_IPV6);
			break;
			default:
				MSG_ERR("unknow skb->protocol %02x\n", skb_in->data[sizeof(struct qmap_hdr)]);
				goto error_pkt;
		}

		if (headroom >= need_headroot) {
			qmap_skb = skb_clone(skb_in, GFP_ATOMIC);
			if (qmap_skb) {
				qmap_skb->dev = qmap_net;
				skb_pull(qmap_skb, sizeof(struct qmap_hdr));
				skb_trim(qmap_skb, skb_len);
			}
			headroom = (qhdr->cd_rsvd_pad&0x3F);
		}
		else {	
			qmap_skb = netdev_alloc_skb(qmap_net, need_headroot + skb_len);
			if (qmap_skb) {
				skb_reserve(qmap_skb, need_headroot);
				skb_put(qmap_skb, skb_len);
				memcpy(qmap_skb->data, skb_in->data + sizeof(struct qmap_hdr), skb_len);
			}
			headroom = pkt_len;
		}
	
		if (qmap_skb == NULL) {
			MSG_ERR("fail to alloc skb, pkt_len = %d\n", pkt_len);
			goto error_pkt;
		}

		skb_reset_mac_header(qmap_skb);
#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
		qmap_skb->protocol = protocol;
		ip_to_ether_fixup(qmap_skb);
#ifdef QUECTEL_BRIDGE_MODE
		bridge_mode_rx_fixup(mhi_netdev, qmap_net, qmap_skb);
#endif
#endif
		skb_queue_tail(&mhi_netdev->skb_chain, qmap_skb);
		//netif_receive_skb(qmap_skb);
		rx_packets++;
		rx_bytes += qmap_skb->len;

skip_pkt:
		skb_pull(skb_in, pkt_len + sizeof(struct qmap_hdr));
	}

#if defined(QUECTEL_UL_DATA_AGG)
	if (rx_packets) {
		struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
		if (rx_packets > ARRAY_SIZE(ctx->qmap_rx_pkts))
			rx_packets = ARRAY_SIZE(ctx->qmap_rx_pkts);
		ctx->qmap_rx_pkts[rx_packets - 1]++;
	}
#endif

#ifdef CONFIG_QCA_NSS_DRV
	if (rcu_dereference(rmnet_nss_callbacks))
		; //nss will update stats
	else
#endif
	mhi_netdev_upate_rx_stats(mhi_netdev, rx_packets, rx_bytes);

	return rx_packets;
error_pkt:
	return rx_packets;
}
#endif

#ifndef CONFIG_MHI_NETDEV_MBIM
static ssize_t qmap_mode_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);

	return snprintf(buf, PAGE_SIZE, "%u\n",  mhi_netdev->qmap_mode);
}

static DEVICE_ATTR(qmap_mode, S_IRUGO, qmap_mode_show, NULL);

static ssize_t qmap_size_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);

	return snprintf(buf, PAGE_SIZE, "%u\n",  mhi_netdev->qmap_size);
}

static DEVICE_ATTR(qmap_size, S_IRUGO, qmap_size_show, NULL);
#endif

#if defined(QUECTEL_UL_DATA_AGG)
static ssize_t qmap_debug_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
	uint *rx = ctx->qmap_rx_pkts;
	uint *tx = ctx->qmap_tx_pkts;
	uint *mx = ctx->tx_agg_match;

	return snprintf(buf, PAGE_SIZE, "rx_pkts: %d, %d, %d, %d, %d, %d, %d, %d\ntx_pkts: %d, %d, %d, %d, %d, %d, %d, %d\nagg_match: %d, %d, %d, %d, %d, %d, %d, %d\n",
		rx[0], rx[1], rx[2], rx[3], rx[4], rx[5], rx[6], rx[7],
		tx[0], tx[1], tx[2], tx[3], tx[4], tx[5], tx[6], tx[7],
		mx[0], mx[1], mx[2], mx[3], mx[4], mx[5], mx[6], mx[7]);
}

static DEVICE_ATTR(qmap_debug, S_IRUGO, qmap_debug_show, NULL);
#endif

static ssize_t link_state_show(struct device *dev, struct device_attribute *attr, char *buf) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);

	return snprintf(buf, PAGE_SIZE, "0x%x\n",  mhi_netdev->link_state);
}

static ssize_t link_state_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	//struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	unsigned link_state = 0;
	unsigned old_link = mhi_netdev->link_state;

	link_state = simple_strtoul(buf, NULL, 0);
	if (mhi_netdev->qmap_mode > 1) {
		if (0 < link_state && link_state <= mhi_netdev->qmap_mode)
			mhi_netdev->link_state |= (1 << (link_state - 1));
		else if (0x80 < link_state && link_state <= (0x80 + mhi_netdev->qmap_mode))
			mhi_netdev->link_state &= ~(1 << ((link_state&0xF) - 1));
	}
	else {
		mhi_netdev->link_state = !!link_state;
	}

	if (old_link != mhi_netdev->link_state) {
		if (mhi_netdev->link_state)
			netif_carrier_on(mhi_netdev->ndev);
		else {
			netif_carrier_off(mhi_netdev->ndev);
	}
		dev_info(dev, "link_state 0x%x -> 0x%x\n", old_link, mhi_netdev->link_state);
	}

	return count;
}

static DEVICE_ATTR(link_state, S_IWUSR | S_IRUGO, link_state_show, link_state_store);

static struct attribute *pcie_mhi_sysfs_attrs[] = {
#ifndef CONFIG_MHI_NETDEV_MBIM
	&dev_attr_qmap_mode.attr,
	&dev_attr_qmap_size.attr,
#endif
#if defined(QUECTEL_UL_DATA_AGG)
	&dev_attr_qmap_debug.attr,
#endif
	&dev_attr_link_state.attr,
#ifdef QUECTEL_BRIDGE_MODE
	&dev_attr_bridge_mode.attr,
	&dev_attr_bridge_ipv4.attr,
#endif
	NULL,
};

static struct attribute_group pcie_mhi_sysfs_attr_group = {
	.attrs = pcie_mhi_sysfs_attrs,
};

#ifndef CONFIG_MHI_NETDEV_MBIM
static int qmap_open(struct net_device *dev)
{
	struct qmap_priv *priv = netdev_priv(dev);
	struct net_device *real_dev = priv->real_dev;

	if (!(priv->real_dev->flags & IFF_UP))
		return -ENETDOWN;

	if (netif_carrier_ok(real_dev))
		netif_carrier_on(dev);
	return 0;
}

static int qmap_stop(struct net_device *pNet)
{
    	netif_carrier_off(pNet);
	return 0;
}

static int qmap_start_xmit(struct sk_buff *skb, struct net_device *pNet)
{
	int err;
	struct qmap_priv *priv = netdev_priv(pNet);

	skb_reset_mac_header(skb);

	if (skb_pull(skb, ETH_HLEN) == NULL) {
	      dev_kfree_skb_any (skb);
	      return NETDEV_TX_OK;
   	}

	add_qhdr(skb, QUECTEL_QMAP_MUX_ID + priv->offset_id);

	skb->dev = priv->real_dev;
	err = dev_queue_xmit(skb);
	if (err == NET_XMIT_SUCCESS) {
		pNet->stats.tx_packets++;
		pNet->stats.tx_bytes += skb->len;
	} else {
		pNet->stats.tx_errors++;
	}

	return err;
}

static const struct net_device_ops qmap_netdev_ops = {
	.ndo_open       = qmap_open,
	.ndo_stop       = qmap_stop,
	.ndo_start_xmit = qmap_start_xmit,
};

static int qmap_register_device(struct mhi_netdev * pDev, u8 offset_id)
{
	struct net_device *real_dev = pDev->ndev;
    	struct net_device *qmap_net;
    	struct qmap_priv *priv;
    	int err;

    	qmap_net = alloc_etherdev(sizeof(*priv));
    	if (!qmap_net)
        		return -ENOBUFS;

    	SET_NETDEV_DEV(qmap_net, &real_dev->dev);
    	priv = netdev_priv(qmap_net);
    	priv->offset_id = offset_id;
    	priv->real_dev = real_dev;
    	sprintf(qmap_net->name, "%s.%d", real_dev->name, offset_id + 1);
    	qmap_net->netdev_ops = &qmap_netdev_ops;
    	memcpy (qmap_net->dev_addr, real_dev->dev_addr, ETH_ALEN);

    	err = register_netdev(qmap_net);
    	if (err < 0)
        		goto out_free_newdev;
    	netif_device_attach (qmap_net);

    	pDev->mpQmapNetDev[offset_id] = qmap_net;
    	qmap_net->flags |= IFF_NOARP;

    	dev_info(&real_dev->dev, "%s %s\n", __func__, qmap_net->name);

    	return 0;

out_free_newdev:
    	free_netdev(qmap_net);
    	return err;
}

static void qmap_unregister_device(struct mhi_netdev * pDev, u8 offset_id) {
	struct net_device *net = pDev->mpQmapNetDev[offset_id];
	if (net != NULL) {
		netif_carrier_off( net );
		unregister_netdev (net);
		free_netdev(net);
	}
}
#endif

#if defined(QUECTEL_UL_DATA_AGG)
static void mhi_netdev_tx_bh(unsigned long param)
{
	struct mhi_netdev *mhi_netdev = (struct mhi_netdev *)param;
	struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
	
	if (mhi_netdev->link_state && ctx->tx_pending_count) {
		struct net_device *dev = mhi_netdev->ndev;

		netif_tx_lock_bh(dev);
		dev->netdev_ops->ndo_start_xmit(NULL, dev);
		netif_tx_unlock_bh(dev);
	}
}

static enum hrtimer_restart mhi_netdev_tx_timer_cb(struct hrtimer *timer)
{
	struct mhi_netdev *mhi_netdev =
			container_of(timer, struct mhi_netdev, tx_ctx.tx_timer);
	struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;

	if (mhi_netdev->link_state && ctx->tx_pending_count) {
		if (ctx->tx_timer_pkts != ctx->tx_sending_pkts) {
			ctx->tx_timer_pkts = ctx->tx_sending_pkts;
			return HRTIMER_RESTART;
		}
		tasklet_schedule(&ctx->tx_bh);
	}
	ctx->tx_timer_active = 0;
	return HRTIMER_NORESTART;
}

#ifdef CONFIG_MHI_NETDEV_MBIM
static struct sk_buff *mhi_mbim_tx_fill_frames(struct mhi_netdev *mhi_netdev,
                                               struct sk_buff *skb_out, struct sk_buff **skbs, uint skb_cnt);
static struct sk_buff *mhi_mbim_netdev_tx_agg(struct sk_buff *skb, struct net_device *ndev, gfp_t flags)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
	struct sk_buff *skb_out = NULL;
	int ready2send = 0;

	if (skb) {
		if (ctx->tx_pending_skb[ctx->tx_pending_count]) {
			dev_info(&ndev->dev, "tx_pending_skb[%d] = %p\n",
				ctx->tx_pending_count, ctx->tx_pending_skb[ctx->tx_pending_count]);
		}
		ctx->tx_pending_skb[ctx->tx_pending_count++] = skb;
		ctx->tx_pending_size += skb->len;

		if (ctx->tx_pending_count >= ctx->ul_data_aggregation_max_datagrams) {
			ctx->tx_agg_match[0]++;
			ready2send = 1;
		} else if (ctx->tx_pending_size >= ctx->ul_data_aggregation_max_size) {
			ctx->tx_agg_match[1]++;
			ready2send = 1;
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,1,0) //6b16f9ee89b8d5709f24bc3ac89ae8b5452c0d7c
		} else if (skb->xmit_more == 0) {
#else
		} else if (netdev_xmit_more() == 0) {
#endif
			if (ctx->tx_timer_active == 0 || agg_time_limit == 0) {
				ctx->tx_agg_match[2]++;
				ready2send = 1;
			}
			else if (skb->data[4] == 0x45) {
				const struct iphdr *iph = (const struct iphdr *)(&(skb->data[4]));
				if (iph->protocol == IPPROTO_TCP) {
					const struct tcphdr *th = (const struct tcphdr *)(&(skb->data[24]));
					if (th->psh) {
						ctx->tx_agg_match[3]++;
						ready2send = 1;
					}
				}
			}
		}
	}
	else if (ctx->tx_pending_count) {
		ctx->tx_agg_match[4]++;
		ready2send =1;
	} else {
		return NULL;
	}

	if (ready2send && ctx->tx_pending_count)
	{
		uint i, skb_count = 0;

		if (ctx->tx_pending_size <= ctx->ul_data_aggregation_max_size) {
			skb_count = ctx->tx_pending_count;
		}
		else {
			skb_count = ctx->tx_pending_count - 1;
		}

		skb_out =  skb_dequeue(&mhi_netdev->tx_allocated);
		if (!skb_out) {
			skb_out = alloc_skb(ctx->ul_data_aggregation_max_size, flags);
			if (skb_out) {
				struct skb_data *entry = (struct skb_data *)(skb_out->cb);
				entry->can_recycle = 1;
				mhi_netdev->stats.tx_allocated++;
			}
		}

		if (skb_out) {
			mhi_mbim_tx_fill_frames(mhi_netdev, skb_out, ctx->tx_pending_skb, skb_count);
			for (i = 0; i < skb_count; i++)
			{
				skb = ctx->tx_pending_skb[i];
				dev_kfree_skb_any(skb);
				ctx->tx_pending_skb[i] = NULL;
			}

			if (skb_count == ctx->tx_pending_count) {
				ctx->tx_pending_count = 0;
				ctx->tx_pending_size = 0;
			}
			else {
				skb = ctx->tx_pending_skb[0] = ctx->tx_pending_skb[skb_count];
				ctx->tx_pending_skb[skb_count] = NULL;
				ctx->tx_pending_count = 1;
				ctx->tx_pending_size = skb->len;
			}
		}
		else {
			dev_info(&ndev->dev, "alloc skb_out fail\n");
			for (i = 0; i < ctx->tx_pending_count; i++) {
				skb = ctx->tx_pending_skb[i];
				dev_kfree_skb_any(skb);
				ctx->tx_pending_skb[i] = NULL;
			}
			ctx->tx_pending_count = 0;
			ctx->tx_pending_size = 0;
		}

		if (skb_out && skb_count) {
			struct skb_data *entry = (struct skb_data *)(skb_out->cb);
			entry->bind_netdev = mhi_netdev;
			entry->packets = skb_count;
			entry->length = skb_out->len;

			if (skb_count > ARRAY_SIZE(ctx->qmap_tx_pkts))
				skb_count = ARRAY_SIZE(ctx->qmap_tx_pkts);
			ctx->qmap_tx_pkts[skb_count - 1]++;
		}
	}

	if (skb_out || ctx->tx_pending_count) {
		if (ctx->tx_timer_active == 0 && agg_time_limit) {
			ctx->tx_timer_active = 1;
			ctx->tx_timer_pkts = ctx->tx_sending_pkts;
			hrtimer_start(&ctx->tx_timer, ms_to_ktime(agg_time_limit), HRTIMER_MODE_REL);
		}
		else if (skb_out) {
			ctx->tx_sending_pkts++;
		}
	}

	return skb_out;
}
#endif

#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
static struct sk_buff *mhi_qmap_netdev_tx_agg(struct sk_buff *skb, struct net_device *ndev, gfp_t flags)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
	struct sk_buff *skb_out = NULL;
	int ready2send = 0;

	if (ctx->ul_data_aggregation_max_datagrams == 1) {
		if (skb) {
			struct skb_data *entry = (struct skb_data *)(skb->cb);
			entry->bind_netdev = mhi_netdev;
			entry->packets = 1;
			entry->length = skb->len;
			entry->can_recycle = 0;
			ctx->qmap_tx_pkts[0]++;
		}
		return skb;
	}

	if (skb) {
		if (ctx->tx_pending_skb[ctx->tx_pending_count]) {
			dev_info(&ndev->dev, "tx_pending_skb[%d] = %p\n",
				ctx->tx_pending_count, ctx->tx_pending_skb[ctx->tx_pending_count]);
		}
		ctx->tx_pending_skb[ctx->tx_pending_count++] = skb;
		ctx->tx_pending_size += skb->len;

		if (ctx->tx_pending_count >= ctx->ul_data_aggregation_max_datagrams) {
			ctx->tx_agg_match[0]++;
			ready2send = 1;
		} else if (ctx->tx_pending_size >= ctx->ul_data_aggregation_max_size) {
			ctx->tx_agg_match[1]++;
			ready2send = 1;
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,1,0) //6b16f9ee89b8d5709f24bc3ac89ae8b5452c0d7c
		} else if (skb->xmit_more == 0) {
#else
		} else if (netdev_xmit_more() == 0) {
#endif
			if (ctx->tx_timer_active == 0 || agg_time_limit == 0) {
				ctx->tx_agg_match[2]++;
				ready2send = 1;
			}
			else if (skb->data[4] == 0x45) {
				const struct iphdr *iph = (const struct iphdr *)(&(skb->data[4]));
				if (iph->protocol == IPPROTO_TCP) {
					const struct tcphdr *th = (const struct tcphdr *)(&(skb->data[24]));
					if (th->psh) {
						ctx->tx_agg_match[3]++;
						ready2send = 1;
					}
				}
			}
		}
	}
	else if (ctx->tx_pending_count) {
		ctx->tx_agg_match[4]++;
		ready2send =1;
	}

	if (ready2send && ctx->tx_pending_count)
	{
		uint i, skb_count = 0;

		if (ctx->tx_pending_size <= ctx->ul_data_aggregation_max_size) {
			skb_count = ctx->tx_pending_count;
		}
		else {
			skb_count = ctx->tx_pending_count - 1;
		}

		skb_out =  skb_dequeue(&mhi_netdev->tx_allocated);
		if (!skb_out) {
			skb_out = alloc_skb(ctx->ul_data_aggregation_max_size, flags);
			if (skb_out) {
				struct skb_data *entry = (struct skb_data *)(skb_out->cb);
				entry->can_recycle = 1;
				mhi_netdev->stats.tx_allocated++;
			}
		}

		if (skb_out) {
			for (i = 0; i < skb_count; i++) {
				skb = ctx->tx_pending_skb[i];
				memcpy(skb_put(skb_out, skb->len), skb->data, skb->len);
				dev_kfree_skb_any(skb);
				ctx->tx_pending_skb[i] = NULL;
			}

			if (skb_count == ctx->tx_pending_count) {
				ctx->tx_pending_count = 0;
				ctx->tx_pending_size = 0;
			}
			else {
				skb = ctx->tx_pending_skb[0] = ctx->tx_pending_skb[skb_count];
				ctx->tx_pending_skb[skb_count] = NULL;
				ctx->tx_pending_count = 1;
				ctx->tx_pending_size = skb->len;
			}
		}
		else {
			dev_info(&ndev->dev, "alloc skb_out fail\n");
			for (i = 0; i < ctx->tx_pending_count; i++) {
				skb = ctx->tx_pending_skb[i];
				dev_kfree_skb_any(skb);
				ctx->tx_pending_skb[i] = NULL;
			}
			ctx->tx_pending_count = 0;
			ctx->tx_pending_size = 0;
		}

		if (skb_out && skb_count) {
			struct skb_data *entry = (struct skb_data *)(skb_out->cb);
			entry->bind_netdev = mhi_netdev;
			entry->packets = skb_count;
			entry->length = skb_out->len;

			if (skb_count > ARRAY_SIZE(ctx->qmap_tx_pkts))
				skb_count = ARRAY_SIZE(ctx->qmap_tx_pkts);
			ctx->qmap_tx_pkts[skb_count - 1]++;
		}
	}

	if (skb_out || ctx->tx_pending_count) {
		if (ctx->tx_timer_active == 0 && agg_time_limit) {
			ctx->tx_timer_active = 1;
			ctx->tx_timer_pkts = ctx->tx_sending_pkts;
			hrtimer_start(&ctx->tx_timer, ms_to_ktime(agg_time_limit), HRTIMER_MODE_REL);
		}
		else if (skb_out) {
			ctx->tx_sending_pkts++;
		}
	}

	return skb_out;
}
#endif
#endif

static int mhi_netdev_xmit(struct sk_buff *skb, struct net_device *ndev)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	int res;
	struct sk_buff *skb_out = NULL;
	struct skb_data *entry;

	MSG_VERB("Entered\n");

	if (likely(skb)) {
		entry = (struct skb_data *)(skb->cb);
		entry->bind_netdev = NULL;
		entry->packets = 1;
		entry->length = skb->len;
		entry->can_recycle = 0;
	}

#ifdef QUECTEL_BRIDGE_MODE
	if (likely(skb && mhi_netdev->bridge_mode)) {
		if (bridge_mode_tx_fixup(ndev, skb, mhi_netdev->bridge_ipv4, mhi_netdev->bridge_mac) == NULL) {
		      dev_kfree_skb_any (skb);
		      return NETDEV_TX_OK;
		}
	}
#endif

	read_lock_bh(&mhi_netdev->pm_lock);

	if (unlikely(!mhi_netdev->enabled)) {
		/* Only reason interface could be disabled and we get data
		 * is due to an SSR. We do not want to stop the queue and
		 * return error. Instead we will flush all the uplink packets
		 * and return successful
		 */
		goto mhi_xmit_exit;
	}

	if (unlikely(!mhi_netdev->link_state))
		goto mhi_xmit_exit;

#ifdef CONFIG_MHI_NETDEV_MBIM
	skb_out = mhi_mbim_netdev_tx_agg(skb, ndev, GFP_ATOMIC);
    skb = MULL;
#else
	if (likely(skb)) {
#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
		if(mhi_netdev->qmap_mode == 1) {
			skb_out = ether_to_ip_fixup(skb);
		} else {
			skb_out = skb;
		}
#endif

		if (likely(skb_out)) {
			if (likely(mhi_netdev->qmap_mode == 1)) {
				skb_out = mhi_qmap_tx_fixup(mhi_netdev, skb_out, ndev);
			} else {
				struct qmap_hdr *qhdr = (struct qmap_hdr *)skb_out->data;
				if ((qhdr->mux_id&0xF0) != 0x80 || ((be16_to_cpu(qhdr->pkt_len) + sizeof(struct qmap_hdr)) != skb->len)) {
					res = NETDEV_TX_OK;
					goto mhi_xmit_exit;
				}
			}
		}
			
		if (unlikely(!skb_out))
			goto mhi_xmit_exit;
	}

#if defined(QUECTEL_UL_DATA_AGG)
	skb_out = mhi_qmap_netdev_tx_agg(skb_out, ndev, GFP_ATOMIC);
	skb = NULL; // to prevent free this skb
#endif
#endif

	if (unlikely(!skb_out))
		goto mhi_xmit_exit;

	qmap_hex_dump(__func__, skb_out->data, skb_out->len);

	res = mhi_get_no_free_descriptors(mhi_dev, DMA_TO_DEVICE);
	if (res == 1)
		netif_stop_queue(ndev);

	entry = (struct skb_data *)(skb_out->cb);
	entry->bind_netdev = mhi_netdev;
	
	res = mhi_queue_transfer(mhi_dev, DMA_TO_DEVICE, skb_out, skb_out->len,
				 MHI_EOT);
	if (res) {
		MSG_VERB("Failed to queue with reason:%d\n", res);
		netif_stop_queue(ndev);
		entry->bind_netdev = NULL;
		if (skb_out != skb) {
			if (entry->can_recycle == 1)
				mhi_netdev_recycle_skb(&mhi_netdev->tx_allocated, skb_out);
			else
			dev_kfree_skb_any(skb_out);
			skb_out = NULL;
		}
		mhi_netdev->stats.tx_full++;
		goto mhi_xmit_exit;
	}

	mhi_netdev->stats.tx_pkts++;

mhi_xmit_exit:
	read_unlock_bh(&mhi_netdev->pm_lock);
	MSG_VERB("Exited\n");

	if (skb_out == NULL && skb != NULL) {
		dev_kfree_skb_any(skb);
	}

	return NETDEV_TX_OK;
}

#if defined(MHI_NETDEV_STATUS64)
static void mhi_netdev_get_stats64(struct net_device *ndev, struct rtnl_link_stats64 *stats)
{
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);

	unsigned int start;
	int cpu;

	netdev_stats_to_stats64(stats, &ndev->stats);

	for_each_possible_cpu(cpu) {
		struct pcpu_sw_netstats *stats64;
		u64 rx_packets, rx_bytes;
		u64 tx_packets, tx_bytes;

		stats64 = per_cpu_ptr(mhi_netdev->stats64, cpu);

		do {
			start = u64_stats_fetch_begin_irq(&stats64->syncp);
			rx_packets = stats64->rx_packets;
			rx_bytes = stats64->rx_bytes;
			tx_packets = stats64->tx_packets;
			tx_bytes = stats64->tx_bytes;
		} while (u64_stats_fetch_retry_irq(&stats64->syncp, start));

		stats->rx_packets += rx_packets;
		stats->rx_bytes += rx_bytes;
		stats->tx_packets += tx_packets;
		stats->tx_bytes += tx_bytes;
	}
}
#endif

#if 1//def CONFIG_ANDROID
typedef unsigned int UINT;
typedef struct {
    UINT size;
    UINT rx_urb_size;
    UINT ep_type;
    UINT iface_id;
    UINT MuxId;
    UINT ul_data_aggregation_max_datagrams; //0x17
    UINT ul_data_aggregation_max_size ;//0x18
    UINT dl_minimum_padding; //0x1A
} QMAP_SETTING;

int qma_setting_store(struct device *dev, QMAP_SETTING *qmap_settings, size_t size) {
	struct net_device *ndev = to_net_dev(dev);
	struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);
	
	if (qmap_settings->size != size) {
		dev_err(dev, "ERROR: qmap_settings.size donot match!\n");
		return -EOPNOTSUPP;
	}

#ifdef QUECTEL_UL_DATA_AGG
	netif_tx_lock_bh(ndev);
	if (mhi_netdev->tx_ctx.ul_data_aggregation_max_datagrams == 1 && qmap_settings->ul_data_aggregation_max_datagrams > 1) {
		mhi_netdev->tx_ctx.ul_data_aggregation_max_datagrams = qmap_settings->ul_data_aggregation_max_datagrams;
		mhi_netdev->tx_ctx.ul_data_aggregation_max_size = qmap_settings->ul_data_aggregation_max_size;
	}
	netif_tx_unlock_bh(ndev);
	return 0;
#endif

	return -EOPNOTSUPP;
}

static int qmap_ndo_do_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd) {
	int rc = -EOPNOTSUPP;
	uint link_state = 0;
 	QMAP_SETTING qmap_settings = {0};
 
	switch (cmd) {
	case 0x89F1: //SIOCDEVPRIVATE
		rc = copy_from_user(&link_state, ifr->ifr_ifru.ifru_data, sizeof(link_state));
		if (!rc) {
			char buf[32];
			snprintf(buf, sizeof(buf), "%u", link_state);
			link_state_store(&dev->dev, NULL, buf, strlen(buf));
		}
	break;

	case 0x89F2: //SIOCDEVPRIVATE
		rc = copy_from_user(&qmap_settings, ifr->ifr_ifru.ifru_data, sizeof(qmap_settings));
		if (!rc) {
			rc = qma_setting_store(&dev->dev, &qmap_settings, sizeof(qmap_settings));
		}
	break;

	default:
	break;
	}

	return rc;
}
#endif

static const struct net_device_ops mhi_netdev_ops_ip = {
	.ndo_open = mhi_netdev_open,
	.ndo_start_xmit = mhi_netdev_xmit,
	//.ndo_do_ioctl = mhi_netdev_ioctl,
	.ndo_change_mtu = mhi_netdev_change_mtu,
#if defined(MHI_NETDEV_STATUS64)
	.ndo_get_stats64	= mhi_netdev_get_stats64,
#endif
#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
//ifconfig: SIOCSIFFLAGS: Cannot assign requested address
	.ndo_set_mac_address = eth_mac_addr,
	.ndo_validate_addr = eth_validate_addr,
#endif
	.ndo_do_ioctl = qmap_ndo_do_ioctl,
};

static void mhi_netdev_get_drvinfo (struct net_device *ndev, struct ethtool_drvinfo *info)
{
	//struct mhi_netdev *mhi_netdev = ndev_to_mhi(ndev);

	strlcpy (info->driver, "pcie_mhi", sizeof info->driver);
	strlcpy (info->version, PCIE_MHI_DRIVER_VERSION, sizeof info->version);
}

static const struct ethtool_ops mhi_netdev_ethtool_ops = {
	.get_drvinfo		= mhi_netdev_get_drvinfo,
};

static void mhi_netdev_setup(struct net_device *dev)
{
	dev->netdev_ops = &mhi_netdev_ops_ip;
	ether_setup(dev);

	dev->ethtool_ops = &mhi_netdev_ethtool_ops;

#ifdef CONFIG_MHI_NETDEV_RMNET_ETH
	memcpy (dev->dev_addr, node_id, sizeof node_id);
#else
	/* set this after calling ether_setup */
	dev->header_ops = 0;  /* No header */
	dev->hard_header_len = 0;
	dev->type = ARPHRD_NONE;
	dev->addr_len = 0;
#endif
	dev->flags |= IFF_NOARP;
	dev->flags &= ~(IFF_BROADCAST | IFF_MULTICAST); //POINTOPOINT will make SFE work wrong
	dev->watchdog_timeo = WATCHDOG_TIMEOUT;
}

/* enable mhi_netdev netdev, call only after grabbing mhi_netdev.mutex */
static int mhi_netdev_enable_iface(struct mhi_netdev *mhi_netdev)
{
	int ret = 0;
#if 0
	char ifalias[IFALIASZ];
#endif
	char ifname[IFNAMSIZ];
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	int no_tre;

	MSG_LOG("Prepare the channels for transfer\n");

	ret = mhi_prepare_for_transfer(mhi_dev);
	if (ret) {
		MSG_ERR("Failed to start TX chan ret %d\n", ret);
		goto mhi_failed_to_start;
	}

	/* first time enabling the node */
	if (!mhi_netdev->ndev) {
		struct mhi_netdev_priv *mhi_netdev_priv;

#if 0
		snprintf(ifalias, sizeof(ifalias), "%s_%04x_%02u.%02u.%02u_%u",
			 mhi_netdev->interface_name, mhi_dev->dev_id,
			 mhi_dev->domain, mhi_dev->bus, mhi_dev->slot,
			 mhi_netdev->alias);
#endif

		snprintf(ifname, sizeof(ifname), "%s%%d",
			 mhi_netdev->interface_name);

		rtnl_lock();
#ifdef NET_NAME_PREDICTABLE
		mhi_netdev->ndev = alloc_netdev(sizeof(*mhi_netdev_priv),
					ifname, NET_NAME_PREDICTABLE,
					mhi_netdev_setup);
#else
		mhi_netdev->ndev = alloc_netdev(sizeof(*mhi_netdev_priv),
					ifname,
					mhi_netdev_setup);
#endif

		if (!mhi_netdev->ndev) {
			ret = -ENOMEM;
			rtnl_unlock();
			goto net_dev_alloc_fail;
		}

		//mhi_netdev->ndev->mtu = mhi_dev->mtu;
		SET_NETDEV_DEV(mhi_netdev->ndev, &mhi_dev->dev);
#if 0
		dev_set_alias(mhi_netdev->ndev, ifalias, strlen(ifalias));
#endif
		mhi_netdev_priv = netdev_priv(mhi_netdev->ndev);
		mhi_netdev_priv->mhi_netdev = mhi_netdev;

#ifdef CONFIG_MHI_NETDEV_MBIM
		mhi_netdev->qmap_mode = 0;
#else
		mhi_netdev->qmap_mode = qmap_mode;
#endif

#if defined(QUECTEL_UL_DATA_AGG)
		{
			struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
			tasklet_init(&ctx->tx_bh, mhi_netdev_tx_bh, (unsigned long)mhi_netdev);
			hrtimer_init(&ctx->tx_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
			ctx->tx_timer.function = &mhi_netdev_tx_timer_cb;
#ifdef CONFIG_MHI_NETDEV_MBIM
			ctx->ul_data_aggregation_max_datagrams = 3;
#else
			ctx->ul_data_aggregation_max_datagrams = 1;
#endif
			ctx->ul_data_aggregation_max_size = 2048;
#ifdef SDX55_LOOPBACK_BUG_FIX
			ctx->ul_data_aggregation_max_datagrams = 16;
			ctx->ul_data_aggregation_max_size = (16*1024);
#endif
		}
#endif

#ifdef QUECTEL_BRIDGE_MODE
		mhi_netdev->bridge_mode = bridge_mode;
#endif
		mhi_netdev->ndev->sysfs_groups[0] = &pcie_mhi_sysfs_attr_group;
		rtnl_unlock();

		netif_napi_add(mhi_netdev->ndev, &mhi_netdev->napi,
			       mhi_netdev_poll, poll_weight);
		ret = register_netdev(mhi_netdev->ndev);
		if (ret) {
			MSG_ERR("Network device registration failed\n");
			goto net_dev_reg_fail;
		}

		netif_carrier_off(mhi_netdev->ndev);
	}

	write_lock_irq(&mhi_netdev->pm_lock);
	mhi_netdev->enabled =  true;
	write_unlock_irq(&mhi_netdev->pm_lock);

	/* queue buffer for rx path */
	no_tre = mhi_get_no_free_descriptors(mhi_dev, DMA_FROM_DEVICE);
	ret = mhi_netdev_alloc_skb(mhi_netdev, GFP_KERNEL);
	if (ret)
		schedule_work(&mhi_netdev->alloc_work);

	napi_enable(&mhi_netdev->napi);

#ifdef CONFIG_QCA_NSS_DRV
	if (mhi_netdev->qmap_mode == 1) {
		struct rmnet_nss_cb *nss_cb = rcu_dereference(rmnet_nss_callbacks);
		if (nss_cb) {
			int rc = nss_cb->nss_create(mhi_netdev->ndev);
			pr_info("nss_create(%s)=%d\n", netdev_name(mhi_netdev->ndev), rc);
		}
	}
#endif

	MSG_LOG("Exited.\n");

	return 0;

net_dev_reg_fail:
	netif_napi_del(&mhi_netdev->napi);
	free_netdev(mhi_netdev->ndev);
	mhi_netdev->ndev = NULL;

net_dev_alloc_fail:
	mhi_unprepare_from_transfer(mhi_dev);

mhi_failed_to_start:
	MSG_ERR("Exited ret %d.\n", ret);

	return ret;
}

static void mhi_netdev_xfer_ul_cb(struct mhi_device *mhi_dev,
				  struct mhi_result *mhi_result)
{
	struct mhi_netdev *mhi_netdev = mhi_device_get_devdata(mhi_dev);
	struct sk_buff *skb = mhi_result->buf_addr;
	struct net_device *ndev = mhi_netdev->ndev;
	struct skb_data *entry = (struct skb_data *)(skb->cb);

	if (entry->bind_netdev != mhi_netdev) {
		MSG_ERR("%s error!\n", __func__);
		return;
	}

	if (likely(mhi_result->transaction_status == 0)) {
		mhi_netdev_upate_tx_stats(mhi_netdev, entry->packets, entry->length);

		if (netif_queue_stopped(ndev) && mhi_netdev->enabled)
			netif_wake_queue(ndev);
	}

	entry->bind_netdev = NULL;
	if (entry->can_recycle == 1) {
		mhi_netdev_recycle_skb(&mhi_netdev->tx_allocated, skb);
	}
	else {
		dev_kfree_skb(skb);
	}
}

static void mhi_netdev_xfer_dl_cb(struct mhi_device *mhi_dev,
				  struct mhi_result *mhi_result)
{
	struct mhi_netdev *mhi_netdev = mhi_device_get_devdata(mhi_dev);
	struct sk_buff *skb = mhi_result->buf_addr;
	struct net_device *ndev = mhi_netdev->ndev;
	struct mhi_skb_priv *skb_priv = (struct mhi_skb_priv *)(skb->cb);

	if (skb_priv->mhi_netdev != mhi_netdev) {
		MSG_ERR("%s error!\n", __func__);
		return;
	}

	if (mhi_result->transaction_status) {
		if (mhi_result->transaction_status != -ENOTCONN)
			MSG_ERR("%s transaction_status = %d!\n", __func__, mhi_result->transaction_status);
		skb_priv->mhi_netdev = NULL;
		dev_kfree_skb(skb);
		return;
	}

	skb_put(skb, mhi_result->bytes_xferd);

	qmap_hex_dump(__func__, skb->data, skb->len);

	skb_priv->mhi_netdev = NULL;
	skb_queue_tail(&mhi_netdev->qmap_chain, skb);
	return;
	
#ifdef CONFIG_MHI_NETDEV_MBIM
	mhi_mbim_rx_fixup(mhi_netdev, skb, ndev);
#else
	mhi_qmap_rx_fixup(mhi_netdev, skb, ndev);
#endif
	skb_priv->mhi_netdev = NULL;
	dev_kfree_skb_any(skb);

	//mhi_netdev->rx_queue(mhi_netdev, GFP_ATOMIC);
}

static void mhi_netdev_status_cb(struct mhi_device *mhi_dev, enum MHI_CB mhi_cb)
{
	struct mhi_netdev *mhi_netdev = mhi_device_get_devdata(mhi_dev);

	if (mhi_cb != MHI_CB_PENDING_DATA)
		return;

	if (napi_schedule_prep(&mhi_netdev->napi)) {
		__napi_schedule(&mhi_netdev->napi);
		mhi_netdev->stats.rx_int++;
		return;
	}

}

#ifdef CONFIG_DEBUG_FS

struct dentry *mhi_netdev_debugfs_dentry;

static int mhi_netdev_init_debugfs_states_show(struct seq_file *m, void *d)
{
	struct mhi_netdev *mhi_netdev = m->private;
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;

#ifdef TS_DEBUG
	struct timespec now_ts, diff_ts;
	getnstimeofday(&now_ts);
	diff_ts = timespec_sub(now_ts, mhi_netdev->diff_ts);
	mhi_netdev->diff_ts = now_ts;
#endif

	seq_printf(m,
		   "tx_tre:%d rx_tre:%d qmap_chain:%u skb_chain:%u tx_allocated:%u rx_allocated:%u\n",
		    mhi_get_no_free_descriptors(mhi_dev, DMA_TO_DEVICE),
		    mhi_get_no_free_descriptors(mhi_dev, DMA_FROM_DEVICE),
		    mhi_netdev->qmap_chain.qlen,
		    mhi_netdev->skb_chain.qlen,
		    mhi_netdev->tx_allocated.qlen,
		    mhi_netdev->rx_allocated.qlen);

	seq_printf(m,
		   "netif_queue_stopped:%d\n",
		    netif_queue_stopped(mhi_netdev->ndev));

#ifdef TS_DEBUG
	seq_printf(m,
		   "qmap_ts:%ld.%ld, skb_ts:%ld.%ld, diff_ts:%ld.%ld\n",
		    mhi_netdev->qmap_ts.tv_sec, mhi_netdev->qmap_ts.tv_nsec,
		    mhi_netdev->skb_ts.tv_sec, mhi_netdev->skb_ts.tv_nsec,
		    diff_ts.tv_sec, diff_ts.tv_nsec);
	mhi_netdev->clear_ts = 1;
#endif

	return 0;
}

static int mhi_netdev_init_debugfs_states_open(struct inode *inode,
					    struct file *fp)
{
	return single_open(fp, mhi_netdev_init_debugfs_states_show, inode->i_private);
}

static const struct file_operations mhi_netdev_debugfs_state_ops = {
	.open = mhi_netdev_init_debugfs_states_open,
	.release = single_release,
	.read = seq_read,
};

static int mhi_netdev_debugfs_trigger_reset(void *data, u64 val)
{
	struct mhi_netdev *mhi_netdev = data;
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	int ret;

	MSG_LOG("Triggering channel reset\n");

	/* disable the interface so no data processing */
	write_lock_irq(&mhi_netdev->pm_lock);
	mhi_netdev->enabled = false;
	write_unlock_irq(&mhi_netdev->pm_lock);
	napi_disable(&mhi_netdev->napi);

	/* disable all hardware channels */
	mhi_unprepare_from_transfer(mhi_dev);

	/* clean up all alocated buffers */
	mhi_netdev_dealloc(mhi_netdev);

	MSG_LOG("Restarting iface\n");

	ret = mhi_netdev_enable_iface(mhi_netdev);
	if (ret)
		return ret;

	return 0;
}
DEFINE_SIMPLE_ATTRIBUTE(mhi_netdev_debugfs_trigger_reset_fops, NULL,
			mhi_netdev_debugfs_trigger_reset, "%llu\n");

static void mhi_netdev_create_debugfs(struct mhi_netdev *mhi_netdev)
{
	char node_name[32];
	int i;
	const umode_t mode = 0600;
	struct dentry *file;
	struct mhi_device *mhi_dev = mhi_netdev->mhi_dev;
	struct dentry *dentry = mhi_netdev_debugfs_dentry;

	const struct {
		char *name;
		u32 *ptr;
	} debugfs_table[] = {
		{
			"rx_int",
			&mhi_netdev->stats.rx_int
		},
		{
			"tx_full",
			&mhi_netdev->stats.tx_full
		},
		{
			"tx_pkts",
			&mhi_netdev->stats.tx_pkts
		},
		{
			"rx_budget_overflow",
			&mhi_netdev->stats.rx_budget_overflow
		},
		{
			"rx_allocated",
			&mhi_netdev->stats.rx_allocated
		},
		{
			"tx_allocated",
			&mhi_netdev->stats.tx_allocated
		},
		{
			"alloc_failed",
			&mhi_netdev->stats.alloc_failed
		},
		{
			NULL, NULL
		},
	};

	/* Both tx & rx client handle contain same device info */
	snprintf(node_name, sizeof(node_name), "%s_%04x_%02u.%02u.%02u_%u",
		 mhi_netdev->interface_name, mhi_dev->dev_id, mhi_dev->domain,
		 mhi_dev->bus, mhi_dev->slot, mhi_netdev->alias);

	if (IS_ERR_OR_NULL(dentry))
		return;

	mhi_netdev->dentry = debugfs_create_dir(node_name, dentry);
	if (IS_ERR_OR_NULL(mhi_netdev->dentry))
		return;

	file = debugfs_create_u32("msg_lvl", mode, mhi_netdev->dentry,
				  (u32 *)&mhi_netdev->msg_lvl);
	if (IS_ERR_OR_NULL(file))
		return;

	/* Add debug stats table */
	for (i = 0; debugfs_table[i].name; i++) {
		file = debugfs_create_u32(debugfs_table[i].name, mode,
					  mhi_netdev->dentry,
					  debugfs_table[i].ptr);
		if (IS_ERR_OR_NULL(file))
			return;
	}

	debugfs_create_file("reset", mode, mhi_netdev->dentry, mhi_netdev,
			    &mhi_netdev_debugfs_trigger_reset_fops);
	debugfs_create_file("states", 0444, mhi_netdev->dentry, mhi_netdev,
				   &mhi_netdev_debugfs_state_ops);
}

static void mhi_netdev_create_debugfs_dir(struct dentry *parent)
{
	mhi_netdev_debugfs_dentry = debugfs_create_dir(MHI_NETDEV_DRIVER_NAME, parent);
}

#else

static void mhi_netdev_create_debugfs(struct mhi_netdev *mhi_netdev)
{
}

static void mhi_netdev_create_debugfs_dir(struct dentry *parent)
{
}

#endif

static void mhi_netdev_remove(struct mhi_device *mhi_dev)
{
	struct mhi_netdev *mhi_netdev = mhi_device_get_devdata(mhi_dev);
	struct sk_buff *skb;

	MSG_LOG("Remove notification received\n");

	write_lock_irq(&mhi_netdev->pm_lock);
	mhi_netdev->enabled = false;
	write_unlock_irq(&mhi_netdev->pm_lock);

#ifdef CONFIG_QCA_NSS_DRV
	if (mhi_netdev->qmap_mode == 1) {
		struct rmnet_nss_cb *nss_cb = rcu_dereference(rmnet_nss_callbacks);
		if (nss_cb) {
			int rc = nss_cb->nss_free(mhi_netdev->ndev);
			pr_info("nss_free(%s)=%d\n", netdev_name(mhi_netdev->ndev), rc);
		}
	}
#endif

#ifndef CONFIG_MHI_NETDEV_MBIM
	if (mhi_netdev->qmap_mode > 1) {
		unsigned i;
		for (i = 0; i < mhi_netdev->qmap_mode; i++) {
			qmap_unregister_device(mhi_netdev, i);
		}
	}
#endif

#if defined(QUECTEL_UL_DATA_AGG)
	if (mhi_netdev->qmap_mode) {
		struct tx_agg_ctx *ctx = &mhi_netdev->tx_ctx;
		uint i, tx_pending_count;

		netif_stop_queue(mhi_netdev->ndev);
		netif_carrier_off(mhi_netdev->ndev);
		netif_tx_lock_bh(mhi_netdev->ndev);
		tx_pending_count = ctx->tx_pending_count;
		ctx->tx_pending_count = 0;
		netif_tx_unlock_bh(mhi_netdev->ndev);
		
		if (hrtimer_active(&ctx->tx_timer))
			hrtimer_cancel(&ctx->tx_timer);
		tasklet_kill(&ctx->tx_bh);

		for (i = 0; i < tx_pending_count; i++) {
			dev_kfree_skb_any(ctx->tx_pending_skb[i]);
		}
	}
#endif

	while ((skb = skb_dequeue (&mhi_netdev->skb_chain)))
		dev_kfree_skb_any(skb);
	while ((skb = skb_dequeue (&mhi_netdev->qmap_chain)))
		dev_kfree_skb_any(skb);
	while ((skb = skb_dequeue (&mhi_netdev->rx_allocated)))
		dev_kfree_skb_any(skb);
	while ((skb = skb_dequeue (&mhi_netdev->tx_allocated)))
		dev_kfree_skb_any(skb);
	
	napi_disable(&mhi_netdev->napi);
	netif_napi_del(&mhi_netdev->napi);
	mhi_netdev_dealloc(mhi_netdev);
	unregister_netdev(mhi_netdev->ndev);
#if defined(MHI_NETDEV_STATUS64)
	free_percpu(mhi_netdev->stats64);
#endif
	free_netdev(mhi_netdev->ndev);
	flush_work(&mhi_netdev->alloc_work);

	if (!IS_ERR_OR_NULL(mhi_netdev->dentry))
		debugfs_remove_recursive(mhi_netdev->dentry);
}

static int mhi_netdev_probe(struct mhi_device *mhi_dev,
			    const struct mhi_device_id *id)
{
	int ret;
	struct mhi_netdev *mhi_netdev;

	mhi_netdev = devm_kzalloc(&mhi_dev->dev, sizeof(*mhi_netdev),
				  GFP_KERNEL);
	if (!mhi_netdev)
		return -ENOMEM;

	mhi_netdev->alias = 0;

	mhi_netdev->mhi_dev = mhi_dev;
	mhi_device_set_devdata(mhi_dev, mhi_netdev);

	mhi_netdev->mru = 0x4000;
	if (mhi_dev->dev_id == 0x0304)//SDX24
		mhi_netdev->mru = 0x4000;
	else if (mhi_dev->dev_id == 0x0306) //SDX55
		mhi_netdev->mru = 0x4000;
#ifdef CONFIG_MHI_NETDEV_MBIM
	mhi_netdev->rx_max = 0x8000;
#endif
	mhi_netdev->qmap_size = mhi_netdev->mru;

#if defined(MHI_NETDEV_STATUS64)
	mhi_netdev->stats64 = netdev_alloc_pcpu_stats(struct pcpu_sw_netstats);
	if (!mhi_netdev->stats64)
		return -ENOMEM;
#endif

	if (!strcmp(id->chan, "IP_HW0"))
		mhi_netdev->interface_name = "pcie_mhi";
	else if (!strcmp(id->chan, "IP_SW0"))
		mhi_netdev->interface_name = "pcie_swip";
	else
		mhi_netdev->interface_name = id->chan;

	mhi_netdev->rx_queue = mhi_netdev_alloc_skb;

	spin_lock_init(&mhi_netdev->rx_lock);
	rwlock_init(&mhi_netdev->pm_lock);
	INIT_WORK(&mhi_netdev->alloc_work, mhi_netdev_alloc_work);
	skb_queue_head_init(&mhi_netdev->qmap_chain);
	skb_queue_head_init(&mhi_netdev->skb_chain);
	skb_queue_head_init(&mhi_netdev->tx_allocated);
	skb_queue_head_init(&mhi_netdev->rx_allocated);

	mhi_netdev->msg_lvl = MHI_MSG_LVL_INFO;

	/* setup network interface */
	ret = mhi_netdev_enable_iface(mhi_netdev);
	if (ret) {
		pr_err("Error mhi_netdev_enable_iface ret:%d\n", ret);
		return ret;
	}

	mhi_netdev_create_debugfs(mhi_netdev);

#ifndef CONFIG_MHI_NETDEV_MBIM
	if (mhi_netdev->qmap_mode == 1) {
		mhi_netdev->mpQmapNetDev[0] = mhi_netdev->ndev;
	} else if (mhi_netdev->qmap_mode > 1) {
		unsigned i;
		for (i = 0; i < mhi_netdev->qmap_mode; i++) {
			qmap_register_device(mhi_netdev, i);
		}
	}
#endif

	return 0;
}

static const struct mhi_device_id mhi_netdev_match_table[] = {
	{ .chan = "IP_HW0" },
	{ .chan = "IP_SW0" },
	{ .chan = "IP_HW_ADPL" },
	{ },
};

static struct mhi_driver mhi_netdev_driver = {
	.id_table = mhi_netdev_match_table,
	.probe = mhi_netdev_probe,
	.remove = mhi_netdev_remove,
	.ul_xfer_cb = mhi_netdev_xfer_ul_cb,
	.dl_xfer_cb = mhi_netdev_xfer_dl_cb,
	.status_cb = mhi_netdev_status_cb,
	.driver = {
		.name = "mhi_netdev",
		.owner = THIS_MODULE,
	}
};

#ifdef CONFIG_QCA_NSS_DRV
extern int __init rmnet_nss_init(void);
extern void __exit rmnet_nss_exit(void);
#endif

int __init mhi_device_netdev_init(struct dentry *parent)
{
#ifdef CONFIG_QCA_NSS_DRV
	RCU_INIT_POINTER(rmnet_nss_callbacks, NULL);
	if (qca_nss_enabled)
		rmnet_nss_init();
#endif
	
	mhi_netdev_create_debugfs_dir(parent);

	return mhi_driver_register(&mhi_netdev_driver);
}

void mhi_device_netdev_exit(void)
{
#ifdef CONFIG_QCA_NSS_DRV
	rmnet_nss_exit();
#endif

#ifdef CONFIG_DEBUG_FS
	debugfs_remove_recursive(mhi_netdev_debugfs_dentry);
#endif
	mhi_driver_unregister(&mhi_netdev_driver);
}

